//
//  ProfileFormLabelCell.swift
//  masai
//
//  Created by Thomas Svitil on 06.09.17.
//  Copyright © 2017 Codepool GmbH. All rights reserved.
//

import UIKit

class ProfileFormLabelCell: FormLabelCell {

}
