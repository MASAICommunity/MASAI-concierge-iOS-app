//
//  PushOpenChatRequest.swift
//  masai
//
//  Created by Florian Rath on 30.11.17.
//  Copyright © 2017 5lvlup gmbh. All rights reserved.
//

import Foundation


struct PushOpenChatRequest {
    
    var hostUrl: String
    var roomId: String
    
}
