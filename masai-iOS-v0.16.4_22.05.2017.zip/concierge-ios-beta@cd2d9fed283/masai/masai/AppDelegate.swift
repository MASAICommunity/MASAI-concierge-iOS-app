//
//  AppDelegate.swift
//  masai
//
//  Created by Bartomiej Burzec on 19.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import Fabric
import Crashlytics
import Auth0

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        Fabric.with([Crashlytics.self])

        let textAttributes = [NSForegroundColorAttributeName:UIColor.greyMasai]
        UINavigationBar.appearance().titleTextAttributes = textAttributes
        UINavigationBar.appearance().tintColor = UIColor.greyMasai
        UINavigationBar.appearance().backgroundColor = UIColor.navigationWhite
        
        UITabBar.appearance().backgroundColor = UIColor.init(colorLiteralRed: 254/255, green: 254/255, blue: 254/255, alpha: 1.0)
        UITabBar.appearance().tintColor = UIColor.orangeMasai
        UITabBar.appearance().layer.borderWidth = 0.0
        UITabBar.appearance().clipsToBounds = true
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        HTTPCookieStorage.shared.cookieAcceptPolicy = .always
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        return Auth0.resumeAuth(url, options: options)
    }
    
    static func openSearch(_ search: String) {
        if let keyWords = search.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed), let url = URL(string:"http://www.google.com/search?q=\(keyWords)") {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    static func callNumber(_ number: String) {
        if let url = URL(string: "tel://\(number)") {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    static func openWebsite(_ address: String!) {
        UIApplication.shared.openURL(URL(string: address)!)
    }
    
    func onReconnectToHost() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.Notification.reconnect), object: nil)
        CRNotifications.showNotification(type: .success, title: "success".localized, message: "reconnect".localized, dismissDelay: 5)
    }

    func logout() {
        if let navigationController = self.window?.rootViewController as? UINavigationController {
            AuthManager.logout()
            navigationController.popToRootViewController(animated: true)
        }
    }
}

