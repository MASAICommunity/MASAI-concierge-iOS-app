//
//  EmptyCollectionViewCell.swift
//  masai
//
//  Created by Bartomiej Burzec on 27.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class EmptyCollectionViewCell: UICollectionViewCell, ChatCell {

    static let identifier = "EmptyCollectionViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    static func calculateHeight(for message: ChatMessage) -> CGFloat {
        return calculateHeight()
    }
    
    static func calculateHeight() -> CGFloat {
        return 50.0
    }
}
