//
//  MainViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 19.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class ConversationListViewController: BaseViewController {
    
    @IBOutlet weak var addConversationButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var conversations = [Conversation]()
    var selectedConversation: Conversation?
    var refreshTimer: Timer?
    var isFirstOpen = true
    let uniqueSubsriptionIdentifier = String.random(length: 50)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
        registerCellForTableView()
        prepareConversationList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshSubsriptions()
        self.refreshTimer = Timer.scheduledTimer(timeInterval: 60.0, target: self, selector: #selector(self.reloadTableView), userInfo: nil, repeats: true)
        
        if self.conversations.isEmpty && self.isFirstOpen {
            selectNewConversation()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isFirstOpen = false
        if let timer = self.refreshTimer {
            timer.invalidate()
        }
        removeSubscriptions()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func isNavigationBarVisible() -> Bool {
        return true
    }
    
    override func titleForNavigationBar() -> String? {
        return "conversationListViewControllerTitle".localized
    }
    
    @objc private func reloadTableView() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    private func registerCellForTableView() {
        self.tableView.register(UINib(nibName: ConversationTableViewCell.identifier, bundle: nil), forCellReuseIdentifier: ConversationTableViewCell.identifier)
    }
    
    private func prepareLayout() {
        self.addConversationButton.layer.shadowColor = UIColor.gray.cgColor
        self.addConversationButton.layer.shadowOpacity = 0.8
        self.addConversationButton.layer.shadowOffset = .zero
        self.addConversationButton.layer.shadowRadius = 10
    }
    
    private func prepareConversationList() {
        if let list = CacheManager.retrieveConversationList() {
            self.conversations = list
        }
        
        if self.conversations.isEmpty {
            LiveChatManager.conversationsForUser(results: { (conversations) in
                self.conversations = conversations
                CacheManager.saveConversationList(self.conversations)
            })
        }
    }
    
    private func refreshSubsriptions() {
        for conversation in self.conversations {
            if let host = conversation.host, let credentials = conversation.credentials {
                
                AuthManager.loginToLiveChat(host: host, credentials: credentials, completion: { (response) in
                    if response?.errorOccured() == true {
                        AlertManager.showError("serverConnectError".localized, controller: self)
                        //TODO: handle user session expiring, remove conversations, remove room from db.
                    } else {
                      self.refresh(conversation: conversation)
                    }
                })
            }
        }
    }
    
    
    private func refresh(conversation: Conversation) {
        SocketManager.subscribe(conversation: conversation, delegate: self)
        SocketManager.sharedInstance.resentUnsentMessages(conversation)
        if self.isFirstOpen {
           SocketRequestManager.loadHistory(conversation)
        }
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }

    }
    
    private func removeSubscriptions() {
        for conversation in self.conversations {
            SocketManager.unsubscribe(conversation: conversation, delegate: self)
        }
    }
    
    @IBAction func onAddConversationButtonPressed(_ sender: Any) {
        selectNewConversation()
    }
    
    private func selectNewConversation() {
        let selectHostViewController = SelectHostViewController()
        let navigationController =  ChatNavigationViewController(rootViewController: selectHostViewController)
        selectHostViewController.selectCompletionBlock = {[weak self](selectedHost) in
            DispatchQueue.main.async {
                self?.onConversationHostSelected(host: selectedHost)
            }
        }
        present(navigationController, animated: true, completion: nil)
    }
    
    
    private func channelExist(_ host: Host) -> Bool {
        for conversation in self.conversations {
            if conversation.host?.name == host.name {
                return true
            }
        }
        return false
    }
    
    private func onConversationHostSelected(host: Host) {
        SocketManager.connect(host) { (socket, connected) in
            if connected {
                if self.channelExist(host) {
                    self.selectConversation(with: host)
                } else {
                    self.createConversation(for: host)
                }
            } else {
                AlertManager.showError("serverConnectError".localized, controller: self)
            }
        }
    }
    
    private func createConversation(for host: Host) {
        SocketRequestManager.registerToLiveChat(host: host) { (response, newChannel, credentials) in
            if let channel = newChannel, let credentials = credentials  {
                self.addConversation(with: host, channel: channel, credentials: credentials)
            } else {
                AlertManager.showError("liveChatError".localized, controller: self)
            }
        }
    }
    
    private func selectConversation(with host:Host) {
        var index = 0
        for conversation in self.conversations {
            if conversation.host?.socket == host.socket {
                self.tableView(self.tableView, didSelectRowAt: IndexPath(row: index, section: 0))
                return
            }
            index += 1
        }
    }
    
    private func addConversation(with host:Host, channel: Channel, credentials: LiveChatCredentials) {
        var index = 0
        for conversation in self.conversations {
            if conversation.channel?.name == channel.name && conversation.host?.socket == host.socket {
                self.tableView(self.tableView, didSelectRowAt: IndexPath(row: index, section: 0))
                return
            }
            index += 1
        }
        
        let newConversation = Conversation(host: host, channel: channel, credentials: credentials)
        self.conversations.append(newConversation)
        SocketManager.subscribe(conversation: newConversation, delegate: self)
        CacheManager.saveConversationList(self.conversations)
        let _ = LiveChatManager.add(newConversation)
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
        self.refresh(conversation: newConversation)
        
        DispatchQueue.main.async {
            self.selectConversation(with: host)
        }
    }
    
}

extension ConversationListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ConversationTableViewCell.defaultHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.conversations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ConversationTableViewCell.identifier) as! ConversationTableViewCell
        let conversationForCell = self.conversations[indexPath.row]
        
        var lastMessageText: String? = ""
        if let lastMessage = conversationForCell.lastMessage() {
            cell.lastMessageDateLabel.text = lastMessage.updated?.timeDifference()
            
            switch lastMessage.dataType() {
            case .googlePlaces:
               lastMessageText = lastMessage.googlePlaces[0].name
            case .attachment, .image:
                if lastMessage.username == conversationForCell.credentials?.liveChatUsername {
                    lastMessageText = "sentFile".localized
                } else {
                    lastMessageText = "receivedFile".localized
                }
                
            case.permission:
                lastMessageText = "travelFolderRequestTitle".localized
            case .link:
                lastMessageText = lastMessage.linkHost
            case .location:
                lastMessageText = "localizationShared".localized
            case .message:
                lastMessageText = lastMessage.messageText
            case .permissionAnswer:
                if lastMessage.permissionAnswerGranted {
                    lastMessageText = "travelFolderAccessGranted".localized
                } else {
                    lastMessageText = "travelFolderAccessDenied".localized
                }
            default:
                break
            }
        }
        
        cell.lastMessageLabel.text = lastMessageText
        cell.avatarLabel.text = conversationForCell.host?.name?.substring(to: 2).uppercased()
        cell.nameLabel.text = conversationForCell.host?.name
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "conversationToChat" {
            let chatVC = segue.destination as! ChatViewController
            chatVC.conversation = self.selectedConversation
        }
    }
}

extension ConversationListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedConversation = self.conversations[indexPath.row]
        performSegue(withIdentifier: Constants.Segue.conversationToChat, sender: nil)
    }
}

extension ConversationListViewController: SubscribedConversationDelegate {
    func onUpdate(message: ChatMessage, response: SocketResponseMessage) {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func delegateIdentifier() -> String {
        return self.uniqueSubsriptionIdentifier
    }
}
