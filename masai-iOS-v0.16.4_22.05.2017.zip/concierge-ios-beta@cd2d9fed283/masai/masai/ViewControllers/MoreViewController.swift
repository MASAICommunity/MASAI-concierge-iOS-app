//
//  MoreViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 26.04.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class MoreViewController: UIViewController {

    @IBOutlet weak var titlelabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titlelabel.text = "comingSoon".localized
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    


}
