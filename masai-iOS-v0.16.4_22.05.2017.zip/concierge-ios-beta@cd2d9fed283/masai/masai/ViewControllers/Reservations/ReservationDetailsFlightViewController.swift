//
//  ReservationDetailsFlightViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 03.03.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import MessageUI

class ReservationDetailsFlightViewController: BaseViewController, MFMailComposeViewControllerDelegate  {
    @IBOutlet weak var flightNameLabel: UILabel!
    @IBOutlet weak var departureLabel: UILabel!
    @IBOutlet weak var arrivalLabel: UILabel!
    @IBOutlet weak var departsLabel: UILabel!
    @IBOutlet weak var arrivesLabel: UILabel!
    @IBOutlet weak var departsTimeLabel: UILabel!
    @IBOutlet weak var departsTerminalLabel: UILabel!
    @IBOutlet weak var departsGateLabel: UILabel!
    @IBOutlet weak var arrivesTimeLabel: UILabel!
    @IBOutlet weak var arrivesTerminalLabel: UILabel!
    @IBOutlet weak var arrivesGateLabel: UILabel!
    @IBOutlet weak var flightDurationLabel: UILabel!
    @IBOutlet weak var passengerNameLabel: UILabel!
    @IBOutlet weak var seatLabel: UILabel!
    @IBOutlet weak var confirmationLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    var flightData = Flight()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fillViewWithData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    private func fillViewWithData() {
        var title = ""
        if let bookingName = self.flightData.bookingName {
            title += bookingName
            self.navigationItem.title = bookingName
        } else {
            self.navigationItem.title = "Flight"
        }
        
        if let detailNumber = self.flightData.detailNumber {
            title += " " + "\(detailNumber)"
        }
        
        self.flightNameLabel.text = title
        self.departureLabel.text = self.flightData.departue.code?.uppercased()
        self.arrivalLabel.text = self.flightData.arrival.code?.uppercased()
        
        var departs = "Departs"
        if let departureDate = self.flightData.departue.localDate, let date = Date.reservationDateString(departureDate) {
            departs += " " + date
            self.departsTimeLabel.text = Date.timeString(departureDate)
        }
        self.departsLabel.text = departs

        var arrives = "Arrives"
        if let arrivesDate = self.flightData.arrival.localDate, let date = Date.reservationDateString(arrivesDate) {
            arrives += " " + date
            self.arrivesTimeLabel.text = Date.timeString(arrivesDate)
        }
        self.arrivesLabel.text = arrives

        self.departsTerminalLabel.text = self.flightData.departue.terminal
        self.departsGateLabel.text = self.flightData.departue.gate
        self.arrivesTerminalLabel.text = self.flightData.arrival.terminal
        self.arrivesGateLabel.text = self.flightData.arrival.gate
        if let duration = self.flightData.duration {
            self.flightDurationLabel.text = "\(duration/60):\(duration%60)"
        }
        
        var passenger = ""
        if let name = self.flightData.traveller.firstName {
            passenger += name
        }
        if let lastName = self.flightData.traveller.lastName {
            passenger += " " + lastName
        }
        self.passengerNameLabel.text = passenger
        
        self.seatLabel.text = "-" //TODO: missing Json field
        self.confirmationLabel.text = self.flightData.bookingConfirmationNumber
        self.emailLabel.text = "-" //TODO: missing Json field
        self.phoneLabel.text = self.flightData.bookingPhone
    }
    
    @IBAction func onPhoneButtonPressed(_ sender: Any) {
        if let phone = self.flightData.bookingPhone?.removingWhitespaces() {
            AppDelegate.callNumber(phone)
        }
    }
    
    @IBAction func onEmailButtonPressed(_ sender: Any) {
        //TODO: missing Json field
    }
    
    private func sendEmail(_ to: String!) {
        let mailVC = MFMailComposeViewController()
        mailVC.mailComposeDelegate = self
        mailVC.setToRecipients([to])
        
        present(mailVC, animated: true, completion: nil)
    }


}
