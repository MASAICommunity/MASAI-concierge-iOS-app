//
//  ReservationDetailsHotelViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 03.03.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import MapKit
import MessageUI

class ReservationDetailsHotelViewController: BaseViewController, MFMailComposeViewControllerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var addresLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var checkInLabel: UILabel!
    @IBOutlet weak var checkOutLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var confirmationNumberLabel: UILabel!
    
    var hotelData = Hotel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addAnnotationToMap()
        fillViewWithData()
        self.navigationItem.title = hotelData.hotelName
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func fillViewWithData() {
        self.addresLabel.text = self.hotelData.address.street
        self.phoneNumberLabel.text = self.hotelData.phone
        self.emailLabel.text = " - "
        
        if let confirmationNumber = self.hotelData.bookingConfirmationNumber {
            self.confirmationNumberLabel.text = confirmationNumber
        }
        
        if let checkInDate = self.hotelData.checkIn {
            self.checkInLabel.text = Date.reservationDateString(checkInDate)
        }
        if let checkOutDate = self.hotelData.checkOut {
            self.checkOutLabel.text = Date.reservationDateString(checkOutDate)
        }
        
        let diffDays = Date.daysBetween(start: self.hotelData.checkIn, end: self.hotelData.checkOut)
        self.durationLabel.text = "\(diffDays) Days"
    }

    private func addAnnotationToMap() {
        if let lat = hotelData.address.latitude, let long = hotelData.address.longitude {
            let hotelAnnotation = PlaceAnnotationView(lat: lat, long: long)
            self.mapView.addAnnotation(hotelAnnotation)
            
            var mapRegion = MKCoordinateRegion()
            mapRegion.center = hotelAnnotation.coordinate
            mapRegion.span.latitudeDelta = 0.008;
            mapRegion.span.longitudeDelta = 0.008;
            mapView.setRegion(mapRegion, animated: false)
        }
    }
    
    @IBAction func onNaviagtionButtonPressed(_ sender: Any) {
        if let lat = hotelData.address.latitude, let long = hotelData.address.longitude {
            let cords = CLLocationCoordinate2DMake(lat, long)
            openNavigationApp(cords, placeName: self.hotelData.hotelName)
        }
    }
    
    @IBAction func onPhoneButtonPressed(_ sender: Any) {
        if let phone = hotelData.phone {
            AppDelegate.callNumber(phone)
        }
    }
    
    @IBAction func onEmailButtonPressed(_ sender: Any) {
        //TODO: wait for correct data model with email fields
    }
  
    private func openNavigationApp(_ cords: CLLocationCoordinate2D, placeName: String?) {
        let regionDistance:CLLocationDistance = 10000
        let coordinates = cords
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = placeName
        mapItem.openInMaps(launchOptions: options)
    }
    
    private func sendEmail(_ to: String!) {
        let mailVC = MFMailComposeViewController()
        mailVC.mailComposeDelegate = self
        mailVC.setToRecipients([to])
        
        present(mailVC, animated: true, completion: nil)
    }
    
}
extension ReservationDetailsHotelViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        return nil
    }
}
