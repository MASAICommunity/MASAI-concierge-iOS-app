//
//  ProfileViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 14.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import WebKit
import Auth0
import Foundation

class ProfileViewController: BaseViewController, WKNavigationDelegate, WKUIDelegate {
    
    @IBOutlet weak var errorLabel: UILabel!
    var webView: WKWebView!
    var webviewReloaded = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "My Travelfolder"
    
        self.webView = WKWebView(frame: self.view.frame)
        self.webView.backgroundColor = .clear
        self.webView.navigationDelegate = self
        self.view.addSubview(webView)
        
        let request = NSMutableURLRequest(url: URL(string: Constants.TravelFolder.endpoint)!)
        self.webView.load(request as URLRequest)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.errorLabel.isHidden = true
        self.webView.reload()
    }
    
    override func isNavigationBarRightItemVisible() -> Bool {
        return true
    }
    
    override func titleForNavigationBarRightItem() -> String? {
        return "logout".localized
    }
    
    override func onPressedNavigationBarRightButton() {
        self.dismiss(animated: true, completion:nil);
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.logout()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        self.errorLabel.isHidden = false
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        /* The travelfolder for some reason needs a second load to properly fill in the data the first time the view is opened. So we reload. */
        if self.webviewReloaded == false {
            self.webviewReloaded = true
            DispatchQueue.main.async {
                self.webView.reload()
            }
        }
        
    }
}
