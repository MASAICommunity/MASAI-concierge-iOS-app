//
//  SelectHostViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 31.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

typealias SelectHostCompletion = (Host) -> Void

class SelectHostViewController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var selectCompletionBlock: SelectHostCompletion?
    var hosts = Host.hardcoded()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCellForTableView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func isNavigationBarVisible() -> Bool {
        return true;
    }
    
    override func titleForNavigationBar() -> String? {
        return "selectHostViewControllerTitle".localized
    }
    
    override func isNavigationBarRightItemVisible() -> Bool {
        return true;
    }
    override func titleForNavigationBarRightItem() -> String? {
        return "close".localized
    }
    
    override func onPressedNavigationBarRightButton() {
        dismiss(animated: true, completion: nil)
    }
    
    private func registerCellForTableView() {
        self.tableView.register(UINib(nibName: HostTableViewCell.identifier, bundle: nil), forCellReuseIdentifier: HostTableViewCell.identifier)
    }
    
}

extension SelectHostViewController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return HostTableViewCell.defaultHeight
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.hosts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: HostTableViewCell.identifier) as! HostTableViewCell
        let host = self.hosts[indexPath.row]
        cell.avatarLabel.text = host.name?.substring(to: 2).uppercased()
        cell.titleLabel.text = host.name
        
        return cell
    }
}

extension SelectHostViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dismiss(animated: true) {
            
            self.selectCompletionBlock?(self.hosts[indexPath.row])
        }
    }
}


