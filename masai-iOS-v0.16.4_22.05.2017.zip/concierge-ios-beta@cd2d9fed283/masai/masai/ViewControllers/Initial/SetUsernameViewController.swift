//
//  SetUsernameViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 17.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import AnimatedTextInput
import UIKit

class SetUsernameViewController: BaseViewController {

    @IBOutlet weak var setUsernameButton: UIButton!
    @IBOutlet weak var userNameTextField: AnimatedTextInput!
    var currentEditingTextField : AnimatedTextInput?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func prepareLayout() {
        userNameTextField.placeHolderText = "username".localized
        userNameTextField.style = MasaiAnimatedTextInputStyle()
        userNameTextField.delegate = self
    }
    
    private func validateUsernameInput() -> Bool {
        if userNameTextField.text == nil || userNameTextField.text == "" {
            userNameTextField.show(error: "emptyLoginError".localized)
            return false
        }
        
        return true
    }
    
    private func setUsername(_ username: String, host: Host) {
        AuthManager.setUsername(username, host: host) { (response) in
            if response.errorOccured() && response.error?.errorCode == Constants.Network.Error.usernameAlreadyInUse {
                let errorMessage = "Username \(username) is arleady in use. Please choose another"
                AlertManager.showError(errorMessage, controller: self)
                self.userNameTextField.show(error: "Please choose another username")
            } else if response.errorOccured() {
                AlertManager.showError(response.error?.message, controller: self)
            } else {
                self.performSegue(withIdentifier: Constants.Segue.setUsernameToMain, sender: nil)
            }
        }
    }
    
    @IBAction func onBackroundTap(_ sender: Any) {
        if currentEditingTextField != nil {
            let _ = currentEditingTextField?.resignFirstResponder()
        }
        
    }
    
    @IBAction func onSetUsernameButtonPressed(_ sender: Any) {
        if validateUsernameInput() {
            setUsername(userNameTextField.text! , host: Host.main())
        }
    }
    
    @IBAction func onBackToLoginButtonPressed(_ sender: Any) {
      let _ = self.navigationController?.popViewController(animated: true)
    }
    
}

extension SetUsernameViewController : AnimatedTextInputDelegate {
    
    func animatedTextInputDidBeginEditing(animatedTextInput: AnimatedTextInput) {
        animatedTextInput.clearError()
        self.currentEditingTextField = animatedTextInput
    }
    
    func animatedTextInputDidEndEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = nil
    }
    
    func animatedTextInputShouldReturn(animatedTextInput: AnimatedTextInput) -> Bool {
        
        if let nextInput = self.view.viewWithTag(animatedTextInput.tag + 1) as? AnimatedTextInput {
            let _ = nextInput.becomeFirstResponder()
        } else {
            let _ = animatedTextInput.resignFirstResponder()
        }
        
        return true
    }
}
