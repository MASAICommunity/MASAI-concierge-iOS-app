//
//  RegisterViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 30.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import AnimatedTextInput
import Typist
import UIKit

class RegisterViewController: BaseViewController {
    
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var usernameTextInput: AnimatedTextInput!
    @IBOutlet weak var emailTextInput: AnimatedTextInput!
    @IBOutlet weak var passTextInput: AnimatedTextInput!
    @IBOutlet weak var repeatTextInput: AnimatedTextInput!
    
    var currentEditingTextField: AnimatedTextInput?
    let keyboardManager = Typist.shared
    var shouldSetUsernameInsteadOfResgister = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        super.viewWillAppear(animated)
        configureKeyboard()
        self.keyboardManager.start()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.keyboardManager.stop()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func configureKeyboard() {
        let _ = self.keyboardManager.on(event: .didShow) { (options) in
            
            if let input = self.currentEditingTextField {
                let inputFrame = self.contentView.convert(input.frame, to: self.view)
                
                let underInputAreaHeight = Double(self.view.frame.size.height - (inputFrame.origin.y + inputFrame.size.height))
                let margin = 10.0
                let keyboardArea = Double(options.endFrame.size.height) + margin
                
                if underInputAreaHeight < keyboardArea {
                    let pointUnderKeyboard = CGPoint.init(x: 0, y: keyboardArea - underInputAreaHeight)
                    self.scrollView.setContentOffset(pointUnderKeyboard, animated: true)
                }
            }
        }
        let _ = self.keyboardManager.on(event: .didHide) { (options) in
            self.scrollView.setContentOffset(.zero, animated: true)
        }
    }
    
    private func prepareLayout() {
        usernameTextInput.placeHolderText = "username".localized
        usernameTextInput.style =  MasaiAnimatedTextInputStyle()
        usernameTextInput.delegate = self
        
        emailTextInput.placeHolderText = "email".localized
        emailTextInput.style =  MasaiAnimatedTextInputStyle()
        emailTextInput.delegate = self
        
        passTextInput.placeHolderText = "pass".localized
        passTextInput.style = MasaiAnimatedTextInputStyle()
        passTextInput.type = .password
        passTextInput.delegate = self
        
        repeatTextInput.placeHolderText = "repeatPass".localized
        repeatTextInput.style =  MasaiAnimatedTextInputStyle()
        repeatTextInput.type = .password
        repeatTextInput.delegate = self
    }
    
    private func validateRegisterForm() -> Bool {
        var result = true
        if usernameTextInput.text == nil || usernameTextInput.text == "" {
            usernameTextInput.show(error: "emptyLoginError".localized)
            result = false
        }
        if emailTextInput.text == nil || emailTextInput.text?.isValidEmail() == false {
            emailTextInput.show(error: "emailError".localized)
            result = false
        }
        
        if passTextInput.text == nil || passTextInput.text == "" {
            passTextInput.show(error: "emptyPassError".localized)
            result = false
        } else if passTextInput.text != repeatTextInput.text {
            repeatTextInput.show(error: "passError".localized)
            passTextInput.show(error: "passError".localized)
            result = false
        }
        
        return result
    }
    
    private func registerUser() {
        self.activityIndicator.isHidden = false
        self.registerButton.isUserInteractionEnabled = false
        if let username = self.usernameTextInput.text, let pass = self.passTextInput.text, let email = self.emailTextInput.text {
            AuthManager.registerAuth0(username, email: email, pass: pass, completion: { (credentials, error) in
                DispatchQueue.main.async {
                    self.activityIndicator.isHidden = true
                    self.registerButton.isUserInteractionEnabled = true
                    if error == nil {
                        self.performSegue(withIdentifier: Constants.Segue.registerToMain, sender: nil)
                    } else {
                        AlertManager.showError(error?.localizedDescription, controller: self)
                    }
                }
            })
        }
    }
    
    private func setUserName(_ username: String, host: Host) {
        AuthManager.setUsername(username, host: host) { (response) in
            if response.errorOccured() && response.error?.errorCode == Constants.Network.Error.usernameAlreadyInUse {
                let errorMessage = "Username \(username) is arleady in use. Please choose another"
                AlertManager.showError(errorMessage, controller: self)
                self.usernameTextInput.show(error: "Please choose another username")
                self.emailTextInput.isEnabled = false
                self.passTextInput.isEnabled = false
                self.repeatTextInput.isEnabled = false
                self.shouldSetUsernameInsteadOfResgister = true
            } else if response.errorOccured() {
                AlertManager.showError(response.error?.message, controller: self)
            } else {
                self.performSegue(withIdentifier: Constants.Segue.registerToMain, sender: nil)
            }
        }
    }
    
    @IBAction func onBackgroundTap(_ sender: Any) {
        if currentEditingTextField != nil {
            let _ = currentEditingTextField?.resignFirstResponder()
        }
    }
    
    @IBAction func onRegisterButtonPressed(_ sender: UIButton) {
        guard validateRegisterForm() else {
            return
        }
        
        if let username = self.usernameTextInput.text, self.shouldSetUsernameInsteadOfResgister  {
            setUserName(username, host: Host.main())
            return
        }
        
        self.registerUser()
    }
    
    @IBAction func onCancelButtonPressed(_ sender: UIButton) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
}

extension RegisterViewController : AnimatedTextInputDelegate {
    
    func animatedTextInputDidBeginEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = animatedTextInput
        animatedTextInput.clearError()
    }
    
    func animatedTextInputDidEndEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = nil
    }
    
    func animatedTextInputShouldReturn(animatedTextInput: AnimatedTextInput) -> Bool {
        
        if let nextInput = self.view.viewWithTag(animatedTextInput.tag + 1) as? AnimatedTextInput {
            let _ = nextInput.becomeFirstResponder()
        } else {
            let _ = animatedTextInput.resignFirstResponder()
        }
        
        return true
    }
}


