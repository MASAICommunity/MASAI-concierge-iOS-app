//
//  SplashViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 19.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class SplashViewController: BaseViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var masaiLogo: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        connectToChat()
        self.activityIndicator.isHidden = false
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func isNavigationBarVisible() -> Bool {
        return false
    }
    
    private func prepareLayout() {
        self.masaiLogo.image = self.masaiLogo.image!.withRenderingMode(.alwaysTemplate)
        self.masaiLogo.tintColor = .orangeMasai
    }
    
    private func connectToChat() {
        SocketManager.connect(Host.main()) { (socket, connected) in
            if connected {
                self.autologin()
                return
            } else {
                AlertManager.showError("serverConnectError".localized, controller: self)
            }
        }
    }
    
    private func autologin() {
        AuthManager.validateAuth0Session(completion: { (succes, error) in
            if succes {
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: Constants.Segue.splashToMain, sender: nil)
                }
                
            } else {
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: Constants.Segue.splashToLogin, sender: nil)
                }
            }
        })
    }
}
