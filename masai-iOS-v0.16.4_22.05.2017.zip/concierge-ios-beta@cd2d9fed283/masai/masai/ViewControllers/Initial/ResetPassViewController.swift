//
//  ResetPassViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 09.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import AnimatedTextInput
import Typist

class ResetPassViewController: BaseViewController {

    @IBOutlet weak var resetPassButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var emailTextField: AnimatedTextInput!
    
    var currentEditingTextField: AnimatedTextInput?
    let keyboardManager = Typist.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        super.viewWillAppear(animated)
        self.keyboardManager.start()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.keyboardManager.stop()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func prepareLayout() {
     self.emailTextField.style = MasaiAnimatedTextInputStyle()
     self.emailTextField.delegate = self
     self.emailTextField.placeHolderText = "email".localized
    }
    
    private func validateEmail() -> Bool {
        if emailTextField.text == nil || emailTextField.text?.isValidEmail() == false {
            emailTextField.show(error: "emailError".localized)
            return false
        }
        return true
    }
    
    private func configureKeyboard() {
        let _ = self.keyboardManager.on(event: .didShow) { (options) in
            
            if let input = self.currentEditingTextField {
                let inputFrame = self.contentView.convert(input.frame, to: self.view)
                
                let underInputAreaHeight = Double(self.view.frame.size.height - (inputFrame.origin.y + inputFrame.size.height))
                let margin = 10.0
                let keyboardArea = Double(options.endFrame.size.height) + margin
                
                if underInputAreaHeight < keyboardArea {
                    let pointUnderKeyboard = CGPoint.init(x: 0, y: keyboardArea - underInputAreaHeight)
                    self.scrollView.setContentOffset(pointUnderKeyboard, animated: true)
                }
            }
        }
        let _ = self.keyboardManager.on(event: .didHide) { (options) in
            self.scrollView.setContentOffset(.zero, animated: true)
        }
    }
    
    @IBAction func onBackToLoginButtonPressed(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onResetPassButtonPressed(_ sender: UIButton) {
        guard validateEmail()  else {
            return
        }
        
        if let emailToReset = self.emailTextField.text {
            self.activityIndicator.isHidden = false
            self.resetPassButton.isUserInteractionEnabled = false
            AuthManager.resetAuth0Pass(emailToReset, completion: { (success) in
                DispatchQueue.main.async {
                    self.activityIndicator.isHidden = true
                    if success {
                        AlertManager.showInfo("resetPassSuccessfully".localized, controller: self, handler: { _ in
                            let _ = self.currentEditingTextField?.resignFirstResponder()
                            let _ = self.navigationController?.popViewController(animated: true)
                        })
                    } else {
                        AlertManager.showInfo("resetPassError".localized, controller: self, handler: nil)
                    }
                    self.resetPassButton.isUserInteractionEnabled = true
                }
            })
        }
    }
    
    @IBAction func onBackgroundTap(_ sender: Any) {
        if currentEditingTextField != nil {
            let _ = currentEditingTextField?.resignFirstResponder()
        }
    }
}

extension ResetPassViewController : AnimatedTextInputDelegate {
    func animatedTextInputDidBeginEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = animatedTextInput
        animatedTextInput.clearError()
    }
    
    func animatedTextInputDidEndEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = nil
    }
    
    func animatedTextInputShouldReturn(animatedTextInput: AnimatedTextInput) -> Bool {
        
        if let nextInput = self.view.viewWithTag(animatedTextInput.tag + 1) as? AnimatedTextInput {
            let _ = nextInput.becomeFirstResponder()
        } else {
            let _ = animatedTextInput.resignFirstResponder()
        }
        return true
    }
}



