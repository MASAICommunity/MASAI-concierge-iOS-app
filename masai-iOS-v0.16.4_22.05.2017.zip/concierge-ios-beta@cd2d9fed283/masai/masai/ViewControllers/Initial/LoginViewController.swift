//
//  LoginViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 25.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//
import AnimatedTextInput
import Typist
import UIKit
import Auth0

class LoginViewController: BaseViewController {
    
    @IBOutlet weak var fbLoginButton: UIButton!
    @IBOutlet weak var googleLoginButton: UIButton!
    @IBOutlet weak var twitterLoginButton: UIButton!
    @IBOutlet weak var linkedinLoginButton: UIButton!
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var resetPassButton: UIButton!
    
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    @IBOutlet weak var loginTextInput: AnimatedTextInput!
    @IBOutlet weak var passTextInput: AnimatedTextInput!
    
    var currentEditingTextField : AnimatedTextInput?
    let keyboardManager  = Typist.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureKeyboard()
        self.keyboardManager.start()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.keyboardManager.stop()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func isNavigationBarVisible() -> Bool {
        return false
    }
    
    private func configureKeyboard() {
        let _ = self.keyboardManager.on(event: .didShow) { (options) in
            
            if let input = self.currentEditingTextField {
                let inputFrame = self.contentView.convert(input.frame, to: self.view)
                
                let underInputAreaHeight = Double(self.view.frame.size.height - (inputFrame.origin.y + inputFrame.size.height))
                let margin = 10.0
                let keyboardArea = Double(options.endFrame.size.height) + margin
                
                if underInputAreaHeight < keyboardArea {
                    let pointUnderKeyboard = CGPoint.init(x: 0, y: keyboardArea - underInputAreaHeight)
                    self.scrollView.setContentOffset(pointUnderKeyboard, animated: true)
                }
            }
        }
        let _ = self.keyboardManager.on(event: .didHide) { (options) in
            self.scrollView.setContentOffset(.zero, animated: true)
        }
    }
    
    private func prepareLayout() {
        resetPassButton.titleLabel?.text = "resetPass".localized
        
        loginTextInput.placeHolderText = "login".localized
        loginTextInput.style =  MasaiAnimatedTextInputStyle()
        loginTextInput.delegate = self
        
        passTextInput.placeHolderText = "pass".localized
        passTextInput.style = MasaiAnimatedTextInputStyle()
        passTextInput.type = .password
        passTextInput.delegate = self
    }
    
    private func validateLoginData() -> Bool {
        var result = true
        if loginTextInput.text == nil || loginTextInput.text == "" {
            loginTextInput.show(error: "emptyLoginError".localized)
            result = false
        }
        
        if passTextInput.text == nil || passTextInput.text == "" {
            passTextInput.show(error: "emptyPassError".localized)
            result = false
        }
        return result
    }
    
    //FIXME: refator login via emial method
    private func login(_ host: Host) {
        if let login = loginTextInput.text, let pass = passTextInput.text {
            self.indicator.isHidden = false
            
            AuthManager.loginAuth0(login, pass: pass, completion: { (credentials, error) in
                DispatchQueue.main.async {
                    self.indicator.isHidden = true
                    self.loginButton.isUserInteractionEnabled = true
                }
                
                if error != nil {
                    AlertManager.showError(error?.localizedDescription, controller: self)
                } else {
                    AuthManager.updateUserProfile(completion: { (user, error) in
                        if error != nil {
                            AlertManager.showError("updateProfileError".localized, controller: self)
                        } else {
                            DispatchQueue.main.async {
                                self.performSegue(withIdentifier: Constants.Segue.loginToMain, sender: nil)
                            }
                        }
                    })
                }
            })
        }
    }
    
    @IBAction func onBackgroundTap(_ sender: UITapGestureRecognizer) {
        if self.currentEditingTextField != nil {
            let _ = self.currentEditingTextField?.resignFirstResponder()
        }
    }
    
    @IBAction func onLoginButtonPressed(_ sender: UIButton) {
        self.loginButton.isUserInteractionEnabled = false
        
        guard validateLoginData() else {
            self.loginButton.isUserInteractionEnabled = true
            return
        }
        
        SocketManager.connect(Host.main()) { (socket, connected) in
            if connected {
                self.login(Host.main())
            } else {
                AlertManager.showError("serverConnectError".localized, controller: self)
                self.loginButton.isUserInteractionEnabled = true
            }
        }
    }
    
    @IBAction func onFacebookLoginButtonPressed(_ sender: UIButton) {
        self.fbLoginButton.isUserInteractionEnabled = false
        AuthManager.loginFacebook { (credentials, error) in
            DispatchQueue.main.async {
                self.fbLoginButton.isUserInteractionEnabled = true
                if error == nil {
                    self.performSegue(withIdentifier: Constants.Segue.loginToMain, sender: nil)
                } else {
                    AlertManager.showError(error?.localizedDescription, controller: self)
                }
            }
        }
    }
    
    @IBAction func onGoogleLoginButtonPressed(_ sender: Any) {
        self.googleLoginButton.isUserInteractionEnabled = false
        AuthManager.loginGoogle { (credentials, error) in
            DispatchQueue.main.async {
                self.googleLoginButton.isUserInteractionEnabled = true
                if error == nil {
                    self.performSegue(withIdentifier: Constants.Segue.loginToMain, sender: nil)
                } else {
                    AlertManager.showError(error?.localizedDescription, controller: self)
                }
            }
        }
    }
    
    @IBAction func onTwitterLoginButtonPressed(_ sender: Any) {
        self.twitterLoginButton.isUserInteractionEnabled = false
        AuthManager.loginTwitter { (credentials, error) in
            DispatchQueue.main.async {
                self.twitterLoginButton.isUserInteractionEnabled = true
                if error == nil {
                    self.performSegue(withIdentifier: Constants.Segue.loginToMain, sender: nil)
                } else {
                    AlertManager.showError(error?.localizedDescription, controller: self)
                }
            }
        }
    }
    
    
    @IBAction func onLinkedinLoginButtonPressed(_ sender: Any) {
        self.linkedinLoginButton.isUserInteractionEnabled = false
        AuthManager.loginLinkedIn { (credentials, error) in
            DispatchQueue.main.async {
                self.linkedinLoginButton.isUserInteractionEnabled = true
                if error == nil {
                    self.performSegue(withIdentifier: Constants.Segue.loginToMain, sender: nil)
                } else {
                    AlertManager.showError(error?.localizedDescription, controller: self)
                }
            }
        }
    }
    
    
    @IBAction func onRegisterButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: Constants.Segue.loginToRegister, sender: nil)
    }
    
    @IBAction func onResetPassButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: Constants.Segue.loginToResetPass, sender: nil)
    }
}

extension LoginViewController : AnimatedTextInputDelegate {
    
    func animatedTextInputDidBeginEditing(animatedTextInput: AnimatedTextInput) {
        animatedTextInput.clearError()
        self.currentEditingTextField = animatedTextInput
    }
    
    func animatedTextInputDidEndEditing(animatedTextInput: AnimatedTextInput) {
        self.currentEditingTextField = nil
    }
    
    func animatedTextInputShouldReturn(animatedTextInput: AnimatedTextInput) -> Bool {
        
        if let nextInput = self.view.viewWithTag(animatedTextInput.tag + 1) as? AnimatedTextInput {
            let _ = nextInput.becomeFirstResponder()
        } else {
            let _ = animatedTextInput.resignFirstResponder()
        }
        
        return true
    }
}
