//
//  ReservationDetailsPublicTransportViewController.swift
//  masai
//
//  Created by Bartomiej Burzec on 03.03.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit

class ReservationDetailsPublicTransportViewController: BaseViewController {

    @IBOutlet weak var trainNameLabel: UILabel!
    @IBOutlet weak var fromLabel: UILabel!
    @IBOutlet weak var toLabel: UILabel!
   
    @IBOutlet weak var departsLabel: UILabel!
    @IBOutlet weak var departsTime: UILabel!
    @IBOutlet weak var departsGateLabel: UILabel!

    @IBOutlet weak var arrivesLabel: UILabel!
    @IBOutlet weak var arrivesTimeLabel: UILabel!
    @IBOutlet weak var arrivesGateLabel: UILabel!
    
    @IBOutlet weak var travelDurationLabel: UILabel!
    @IBOutlet weak var passengerNameLabel: UILabel!
    @IBOutlet weak var seatLabel: UILabel!
    @IBOutlet weak var classTypeLabel: UILabel!
    @IBOutlet weak var confirmationLabel: UILabel!
    @IBOutlet weak var linkLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    var publicTransportData = PublicTransport()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fillViewWithData()
    }

    private func fillViewWithData() {
        if let trainNumber = self.publicTransportData.trainNumber {
            self.navigationItem.title = trainNumber
            self.trainNameLabel.text = trainNumber
        } else {
            self.navigationItem.title = "Train"
        }
        self.fromLabel.text = self.publicTransportData.departure.name
        self.toLabel.text = self.publicTransportData.arrival.name
        
        var departs = "Departs"
        if let departureDate = self.publicTransportData.departure.localDate, let date = Date.reservationDateString(departureDate) {
            departs += " " + date
            self.departsTime.text = Date.timeString(departureDate)
        }
        self.departsLabel.text = departs
        
        var arrives = "Arrives"
        if let arrivesDate = self.publicTransportData.arrival.localDate, let date = Date.reservationDateString(arrivesDate) {
            arrives += " " + date
            self.arrivesTimeLabel.text = Date.timeString(arrivesDate)
        }
        self.arrivesLabel.text = arrives
        
        self.departsGateLabel.text = self.publicTransportData.departure.platform
        self.arrivesGateLabel.text = self.publicTransportData.arrival.platform

        if let duration = self.publicTransportData.duration {
            self.travelDurationLabel.text = "\(duration/60) \(duration%60)"
        }
        
        var name = ""
        if let firstName = self.publicTransportData.traveller.firstName {
            name += " " + firstName
        }
        if let lastName = self.publicTransportData.traveller.lastName {
            name += " " + lastName
        }
        
        self.classTypeLabel.text = self.publicTransportData.classType
        self.linkLabel.text = self.publicTransportData.bookingDetailsUrl
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func onUrlButtonPressed(_ sender: Any) {
        if let url = self.publicTransportData.bookingDetailsUrl {
            AppDelegate.openWebsite(url)
        }
    }
    
    @IBAction func onPhoneButtonPressed(_ sender: Any) {
        //TODO: wait for correct public transport models
    }
    
    
}
