//
//  AuthManager.swift
//  masai
//
//  Created by Bartomiej Burzec on 27.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//
import Auth0

typealias LoginResponseCompletion  = (SocketResponseMessage?, User?) -> Void
typealias LoginAuth0ResponseCompletion = (Credentials?, Error?) -> Void
typealias LoginAuth0ValidateSessionCompletion = (Bool, Error?) -> Void
typealias UpdateAuth0UserDataCompletion = (User?, Error?) -> Void
typealias RegisterAuth0Completion = (Credentials?, Error?) -> Void
typealias RefreshAuthTokenCompletion = (Bool, Error?) -> Void
typealias LoginFacebookResponseCompletion = (Credentials?, Error?) -> Void
typealias LoginGoogleResponseCompletion = (Credentials?, Error?) -> Void
typealias LoginTwitterResponseCompletion = (Credentials?, Error?) -> Void
typealias LoginLinkedInResponseCompletion = (Credentials?, Error?) -> Void
typealias LoginToLiveChatResponseCompletion = (SocketResponseMessage?) -> Void

struct AuthManager {
    
    static func logout() {
        CacheManager.removeConversationList()
        CacheManager.retrieveLoggedUser()?.clearCredentials()
        CacheManager.removeLoggedUser()
        AuthManager.clearAuthCookies()
        SocketManager.sharedInstance.clear()
    }
    
    static func clearAuthCookies() {
        if let cookies = HTTPCookieStorage.shared.cookies {
            for cookie in cookies {
                if cookie.name == "id_token" {
                   HTTPCookieStorage.shared.deleteCookie(cookie)
                    print("deleted cookie")
                }
            }
        }
    }
    
    static func setAuthCookie() {
        if let authToken = CacheManager.retrieveLoggedUser()?.auth0IdToken {
            
        var cookieProperties = [HTTPCookiePropertyKey: Any]()
        cookieProperties[HTTPCookiePropertyKey.domain] = "travelfolder.masai.solutions"
        cookieProperties[HTTPCookiePropertyKey.originURL] = "travelfolder.masai.solutions"
        cookieProperties[HTTPCookiePropertyKey.name] = "id_token"
        cookieProperties[HTTPCookiePropertyKey.value] = authToken
        cookieProperties[HTTPCookiePropertyKey.path] = "/"
        cookieProperties[HTTPCookiePropertyKey.version] = "0"
        
        cookieProperties[HTTPCookiePropertyKey.expires] = NSDate().addingTimeInterval(2629743)
        
        let cookie = HTTPCookie.init(properties: cookieProperties)
        
        HTTPCookieStorage.shared.setCookie(cookie!)
            
        }
    }
    
    static func resetAuth0Pass(_ email: String, completion: @escaping ResetAuth0UserPass) {
        RestManager.resetAuth0UserPass(email, completion: completion)
    }
    
    static func validateAuth0Session(completion: @escaping LoginAuth0ValidateSessionCompletion) {
        if let loginCachedUser = CacheManager.retrieveLoggedUser() {
            guard let token = loginCachedUser.auth0AccessToken else {
                completion(false, nil)
                return
            }
            
            Auth0
                .authentication()
                .userInfo(token: token)
                .start { result in
                    switch(result) {
                    case .success(let profile):
                        var user = loginCachedUser
                        user.update(with: profile)
                        CacheManager.saveLoggedUser(user)
                        
                        DispatchQueue.main.async {
                            completion(true, nil)
                        }
                        
                    case .failure(let error):
                        DispatchQueue.main.async {
                           completion(false, error)
                        }
                        return
                    }
            }
        } else {
            DispatchQueue.main.async {
                completion(false, nil)
            }
        }
    }
    
    
    
    static func loginAuth0(_ username: String, pass: String, completion: @escaping LoginAuth0ResponseCompletion) {
        
        Auth0.authentication().login(
            usernameOrEmail: username,
            password: pass,
            connection: "Username-Password-Authentication",
            scope: "openid profile"
            )
            .start { result in
                switch result {
                case .success(let credentials):
                    
                    var newUser = User()
                    newUser.update(with: credentials)
                    newUser.authType = .standard
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                            completion(credentials, nil)
                        }
                    })
                    
                case .failure(let error):
                    DispatchQueue.main.async {
                       completion(nil, error)
                    }
                }
        }
        
    }
    
    static func loginFacebook(completion: @escaping LoginFacebookResponseCompletion) {
        Auth0
            .webAuth()
            .connection("facebook")
            .connectionScope("public_profile,email,user_friends")
            .scope("openid")
            .start { result in
                switch result {
                case .success(let credentials):
                    
                    var newUser = User()
                    newUser.update(with: credentials)
                    newUser.authType = .fb
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                            completion(credentials, nil)
                        }
                    })
                    
                case .failure(let error):
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
        }
        
    }
    
    static func loginGoogle(completion: @escaping LoginGoogleResponseCompletion) {
        Auth0
            .webAuth()
            .connection("google-oauth2")
            .scope("openid")
            .start { result in
                switch result {
                case .success(let credentials):
                    
                    var newUser = User()
                    newUser.update(with: credentials)
                    newUser.authType = .google
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                           completion(credentials, nil)
                        }
                    })
                    
                case .failure(let error):
                    DispatchQueue.main.async {
                       completion(nil, error)
                    }
                }
        }
        
    }
    
    static func loginLinkedIn(completion: @escaping LoginLinkedInResponseCompletion) {
        Auth0
            .webAuth()
            .connection("linkedin")
            .scope("openid")
            .start { result in
                switch result {
                case .success(let credentials):
                    
                    var newUser = User()
                    newUser.update(with: credentials)
                    newUser.authType = .twitter
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                            completion(credentials, nil)
                        }
                    })
            
                case .failure(let error):
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
        }
        
    }
    
    static func loginTwitter(completion: @escaping LoginTwitterResponseCompletion) {
        Auth0
            .webAuth()
            .connection("twitter")
            .scope("openid")
            .start { result in
                switch result {
                case .success(let credentials):
                    
                    var newUser = User()
                    newUser.update(with: credentials)
                    newUser.authType = .twitter
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                            completion(credentials, nil)
                        }
                    })
                    
                case .failure(let error):
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
        }
        
    }
    
    static func updateUserProfile(completion: UpdateAuth0UserDataCompletion? = nil) {
        if let cachedUser = CacheManager.retrieveLoggedUser(), let token = cachedUser.auth0AccessToken {
            Auth0
                .authentication()
                .userInfo(token: token)
                .start { result in
                    switch(result) {
                    case .success(let profile):
                        var user = cachedUser
                        
                        user.update(with: profile)
                        CacheManager.saveLoggedUser(user)
                        AuthManager.setAuthCookie()
                        DispatchQueue.main.async {
                            completion?(user, nil)
                        }
                        
                    case .failure(let error):
                        logout()
                        DispatchQueue.main.async {
                           completion?(nil, error)
                        }
                    }
            }
        } else {
            logout()
            DispatchQueue.main.async {
                completion?(nil, nil)
            }
        }
    }
    
    
    static func registerAuth0(_ username: String, email: String, pass: String, completion: @escaping RegisterAuth0Completion) {
        
        Auth0
            .authentication()
            .signUp(
                email: email,
                username: username,
                password: pass,
                connection: "Username-Password-Authentication"
            )
            .start { result in
                switch result {
                case .success(let credentials):
                    var newUser = User()
                    newUser.username = username
                    newUser.email = email
                    newUser.authType = .standard
                    newUser.update(with: credentials)
                    CacheManager.saveLoggedUser(newUser)
                    
                    updateUserProfile(completion: { _ in
                        DispatchQueue.main.async {
                            completion(credentials, nil)
                        }
                    })
                    
                case .failure(let error):
                    completion(nil, error)
                }
        }
    }
    
    static func refreshAuthToken(completion: RefreshAuthTokenCompletion?) {
        if let cachedUser = CacheManager.retrieveLoggedUser(), let refreshToken = cachedUser.auth0refreshToken {
            Auth0
                .authentication()
                .delegation(withParameters: ["refresh_token": refreshToken,
                                             "scope": "openid email",
                                             "api_type": "app"])
                .start { result in
                    switch(result) {
                    case .success(let credentials):
                        var user = cachedUser
                        
                        if let newToken = credentials["id_token"] as? String {
                            user.update(newToken: newToken)
                            CacheManager.saveLoggedUser(user)
                            updateUserProfile(completion: { _ in
                                DispatchQueue.main.async {
                                    completion?(true, nil)
                                }
                            })
                        } else {
                            DispatchQueue.main.async {
                                completion?(false, nil)
                            }
                        }
                        
                    case .failure(let error):
                        logout()
                        DispatchQueue.main.async {
                            completion?(false, error)
                        }
                    }
            }
        }
    }
    
    static func loginCachedUser(to host: Host, completion: @escaping LoginResponseCompletion) {
        if let cachedUser = CacheManager.retrieveLoggedUser(), let pass = cachedUser.pass {
            var username: String?
            if cachedUser.username != nil {
                username = cachedUser.username
            } else if cachedUser.email != nil {
                username = cachedUser.email
            }
            if let username = username {
                login(username, pass: pass, host: host, completion: completion)
            } else {
                completion(nil, nil)
            }
            
        } else {
            completion(nil, nil)
        }
    }
    
    
    static func loginToLiveChat(host: Host, credentials: LiveChatCredentials, completion: @escaping LoginToLiveChatResponseCompletion) {
        
        if let token = credentials.liveChatToken {
            SocketRequestManager.loginToLiveChat(host: host, token: token, completion: { (response) in
                completion(response)
            })
        } else {
            completion(nil)
        }
    }
    
    static func login(_ username: String, pass: String, host:Host, completion: @escaping LoginResponseCompletion) {
        
        ///  FIXME: hotfix
        var user = CacheManager.retrieveLoggedUser()
        if user == nil {
            user = User()
            
        }
        var loginType = Constants.Network.Json.email
        
        if username.contains("@") {
            user?.email = username
        } else {
            user?.username = username
            loginType = Constants.Network.Json.username
        }
        user?.pass = pass
        
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.login,
            Constants.Network.Json.params: [[
                Constants.Network.Json.user: [
                    loginType: username
                ],
                Constants.Network.Json.password: [
                    Constants.Network.Json.digest: pass.sha256(),
                    Constants.Network.Json.algorithm: Constants.Network.Json.sha256
                ]
                ]]
            ] as [String : Any]
        
        SocketManager.send(requestObject, host: host) { (response) in
            guard response.errorOccured() == false else {
                completion(response, nil)
                return
            }
            
            user?.update(with: response.responseData)
            CacheManager.saveLoggedUser(user!)
            completion(response, user)
        }
    }
    
    static func setUsername(_ username: String, host: Host, completion: SocketManagerMessageCompletion? = nil) {
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.setUsername,
            Constants.Network.Json.params: [
                username]
            ] as [String: Any]
        
        SocketManager.send(requestObject, host: host) { (response) in
            if let completion = completion {
                var user = CacheManager.retrieveLoggedUser()
                if user != nil && response.errorOccured() == false {
                    user?.username = username
                    CacheManager.saveLoggedUser(user!)
                }
                completion(response)
            }
        }
    }
    
    static func loginToRocketChat(token: String, secret: String) {
        
        let requestObject = [
            Constants.Network.Json.message: Constants.Network.Json.method,
            Constants.Network.Json.method: Constants.Network.Methods.login,
            Constants.Network.Json.params: [["oauth":[
                "credentialToken":token,
                "credentialSecret":"QzSu-LOP0ETyTIAto7Sz8L5WAU2vpMxzIqDAQ9Trcr3KXz3zxIaViq34bV8pnGsd"
                ] ]]
            ] as [String : Any]
        
        
        SocketManager.send(requestObject, host: Host.main()) { (response) in
            print("ROCKET CHAT OAUTH login response \(response)")
        }
        
    }
    
    
    static func register(_ username: String, email: String, pass: String, host: Host, completion: @escaping SocketManagerMessageCompletion) {
        
        let requestObject = [Constants.Network.Json.message: Constants.Network.Json.method,
                             Constants.Network.Json.method: Constants.Network.Methods.register,
                             Constants.Network.Json.params: [[
                                Constants.Network.Json.name: username,
                                Constants.Network.Json.email: email,
                                Constants.Network.Json.pass: pass,
                                Constants.Network.Json.confirmPass: pass]
            ]] as [String: Any]
        
        SocketManager.send(requestObject, host: host) { (response) in
            if response.errorOccured() == false {
                login(email, pass: pass, host: host, completion: { (loginResponse, user) in
                    if let response = loginResponse {
                        completion(response)
                    }
                    //TODO: to handle
                })
            } else {
                completion(response)
            }
        }
    }
    
    
}
