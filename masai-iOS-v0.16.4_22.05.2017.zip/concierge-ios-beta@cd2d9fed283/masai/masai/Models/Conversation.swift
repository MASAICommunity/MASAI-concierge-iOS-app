//
//  Conversation.swift
//  masai
//
//  Created by Bartłomiej Burzec on 07.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Pantry
import Foundation
import RealmSwift
import SwiftyJSON

struct Conversation: Storable {
    var host: Host?
    var channel: Channel?
    var credentials: LiveChatCredentials?
    
    init() {}
    
    init(host: Host, channel: Channel, credentials: LiveChatCredentials) {
        self.host = host
        self.channel = channel
        self.credentials = credentials
    }
    
    init(_ room: LiveChatRoom) {
        self.host = Host(url: room.hostUrl, socket: room.hostSocket, name: room.hostname)
        self.channel = Channel(name: room.channelName, identifier: room.channelIdentifier, rid: room.channelRid)
        self.credentials = LiveChatCredentials(token: room.liveChatToken, userId: room.liveChatUserId, username: room.liveChatUsername)
    }
    
    init?(warehouse: Warehouseable) {
        self.channel = warehouse.get("ConversationChannel")
        self.host = warehouse.get("ConversationHost")
        self.credentials = warehouse.get("ConversationCredentials")
    }
    
    func toDictionary() -> [String : Any] {
        var dictionary = [String: Any]()
        if let channel = self.channel {
            dictionary["ConversationChannel"] = channel.toDictionary()
        }
        
        if let host = self.host {
            dictionary["ConversationHost"] = host.toDictionary()
        }
        
        if let credentials = self.credentials {
            dictionary["ConversationCredentials"] = credentials.toDictionary()
        }
        
        return dictionary
    }
    
    func messages() -> [ChatMessage] {
        guard let rid = self.channel?.rid, let messages = try? Realm().objects(ChatMessage.self).filter("rid == %@", rid).sorted(byKeyPath: "date", ascending: false) else {
            return [ChatMessage]()
        }
        return messages.flatMap({ $0 as ChatMessage })
    }
    
    func lastMessages(_ from: Date) -> [ChatMessage] {
        guard let rid = self.channel?.rid, let messages = try? Realm().objects(ChatMessage.self).filter("rid == %@ AND updated > %@", rid, from as NSDate).sorted(byKeyPath: "date", ascending: true) else {
            return [ChatMessage]()
        }
        return messages.flatMap({ $0 as ChatMessage })
    }
    
    func unsentMessages() -> [ChatMessage] {
        guard let rid = self.channel?.rid, let messages = try? Realm().objects(ChatMessage.self).filter("rid == %@ AND sending == NO AND sent == NO", rid) else {
            return [ChatMessage]()
        }
        return messages.flatMap({ $0 as ChatMessage })
    }
    
    func lastMessage() -> ChatMessage? {
        guard let rid = self.channel?.rid else {
            return nil
        }
        
        if let lastMsg = try? Realm().objects(ChatMessage.self).filter("rid == %@", rid).sorted(byKeyPath: "date", ascending: true).flatMap({$0 as ChatMessage}).last {
            return lastMsg
        } else {
            return nil
        }
    }
    
    func textMessageForTravelFolderAccess(_ permision: Bool) -> String? {
        if let rid = self.channel?.rid, let user = CacheManager.retrieveLoggedUser(), let userId = user.identifier {
            var status = Constants.Network.PermissionsTypes.denied
            if permision {
                status = Constants.Network.PermissionsTypes.granted
            }

            let jsonMessage = [Constants.Network.Json.status: status,
                               Constants.Network.Json.granted: userId,
                               Constants.Network.Json.rid: rid]
            
            return JSON(jsonMessage).rawString()
        }
        return nil
    }
}

