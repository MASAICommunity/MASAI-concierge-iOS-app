//
//  Host.swift
//  masai
//
//  Created by Bartomiej Burzec on 31.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//
import Pantry
import Foundation

struct Host: Storable {
    var url : String?
    var socket: String?
    var name: String?
    
    init() {}

    init(url: String?, socket: String?, name: String?) {
        self.url = url
        self.socket = socket
        self.name = name
    }
    
    init?(warehouse: Warehouseable) {
        self.url = warehouse.get("HostUrl")
        self.socket = warehouse.get("HostSocket")
        self.name = warehouse.get("HostName")
    }
    
    func toDictionary() -> [String : Any] {
        var dictionary = [String: Any]()
        if let url = self.url {
            dictionary["HostUrl"] = url
        }
        if let socket = self.socket {
            dictionary["HostSocket"] = socket
        }
        if let name = self.name {
            dictionary["HostName"] = name
        }
        return dictionary
    }
    
    static func hardcoded() -> [Host] {
        var mogree = Host()
        mogree.url = "http://demo.masai.solutions:3001"
        mogree.socket = "ws://demo.masai.solutions:3001/websocket"
        mogree.name = "DB Concierge"
        
        var demo = Host()
        demo.url = "https://demo.rocket.chat"
        demo.socket = "wss://demo.rocket.chat/websocket"
        demo.name = "Demo Rocket Chat Server"
        
        var embiq = Host()
        embiq.url = "http://demo.masai.solutions:3000"
        embiq.socket = "ws://demo.masai.solutions:3000/websocket"
        embiq.name = "DB Concierge 3000"
        
        return [mogree]
    }
    
    static func main() -> Host {
      return hardcoded()[0]
    }
    
    func restEndpoint(_ methodName: String) -> String {
        if let url = self.url, let method = methodName.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed) {
            return url + method
        }
        return ""
    }
    
}
