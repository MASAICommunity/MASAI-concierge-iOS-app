//
//  FileForUpload.swift
//  masai
//
//  Created by Bartomiej Burzec on 23.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation

struct FileForUpload {
    var name: String
    var size: Int
    var type: String
    var data: Data
}
