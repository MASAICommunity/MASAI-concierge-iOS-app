//
//  ChatBottomMargin.swift
//  masai
//
//  Created by Bartomiej Burzec on 27.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation
import UIKit

struct ChatBottomMargin: ChatData {
    
    func dataType() -> ChatDataType {
        return .bottomMargin
    }
    
}
