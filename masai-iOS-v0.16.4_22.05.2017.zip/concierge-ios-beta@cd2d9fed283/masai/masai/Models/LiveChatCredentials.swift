//
//  LiveChatCredentials.swift
//  masai
//
//  Created by Bartomiej Burzec on 11.04.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Foundation
import Pantry

struct LiveChatCredentials: Storable {
    var liveChatToken: String?
    var liveChatUserId: String?
    var liveChatUsername: String?
    
    init() {}
    
    init(token: String?, userId: String?, username: String?) {
        self.liveChatToken = token
        self.liveChatUserId = userId
        self.liveChatUsername = username
    }
    
    init?(warehouse: Warehouseable) {
        self.liveChatToken = warehouse.get("ConverstationLiveChatToken")
        self.liveChatUserId = warehouse.get("ConversationLiveChatUserId")
        self.liveChatUsername = warehouse.get("ConversationLiveChatUsername")
    }
    
    func toDictionary() -> [String : Any] {
        var dictionary = [String: Any]()
        if let liveToken = self.liveChatToken {
            dictionary["ConverstationLiveChatToken"] = liveToken
        }
        
        if let liveUserId = self.liveChatUserId {
            dictionary["ConversationLiveChatUserId"] = liveUserId
        }
        
        if let liveUsername = self.liveChatUsername {
            dictionary["ConversationLiveChatUsername"] = liveUsername
        }
        
        return dictionary
    }
}
