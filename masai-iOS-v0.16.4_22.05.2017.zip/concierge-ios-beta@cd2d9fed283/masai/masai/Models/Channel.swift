//
//  Channel.swift
//  masai
//
//  Created by Bartomiej Burzec on 06.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import Pantry
import SwiftyJSON
import Foundation

struct Channel: Storable {
    var name: String?
    var identifier: String?
    var rid: String?
    //FIXME: probably vars to remove
    var lastUpdate: Date?
    var liveChatToken: String?
    /*  */
    
    init() {}
    
    init(name: String?, identifier: String?, rid: String?) {
        self.name = name
        self.identifier = identifier
        self.rid = rid
    }
    
    init(_ json: JSON) {
        update(with: json)
    }
    
    init?(warehouse: Warehouseable) {
        self.name = warehouse.get("ChannelName")
        self.identifier = warehouse.get("ChannelIdentifier")
        self.rid = warehouse.get("ChannelRid")
        self.lastUpdate = Date.dateFromMasaiTimestamp(warehouse.get("ChannelLastUpdate"))
        self.liveChatToken = warehouse.get("ChannelLiveChatToken")
    }
    
    mutating func update(with json: JSON) {
        self.name = json[Constants.Network.Json.name].string
        self.identifier = json[Constants.Network.Json.identifier].string
        self.rid = json[Constants.Network.Json.rid].string
        self.lastUpdate = Date.dateFromMasaiTimestamp(json[Constants.Network.Json.updated][Constants.Network.Json.date].double)
        self.liveChatToken = json[Constants.Network.Json.token].string
    }
    
    func toDictionary() -> [String : Any] {
        var dictionary = [String: Any]()
        if let name = self.name {
            dictionary["ChannelName"] = name
        }
        if let identifier = self.identifier{
            dictionary["ChannelIdentifier"] = identifier
        }
        if let rid = self.rid {
            dictionary["ChannelRid"] = rid
        }
        if let lastUpdate = self.lastUpdate {
            dictionary["ChannelLastUpdate"] = Date.masaiTimestampFromDate(lastUpdate)
        }
        if let liveChatToken = self.liveChatToken {
            dictionary["ChannelLiveChatToken"] = liveChatToken
        }

        return dictionary
    }
}
