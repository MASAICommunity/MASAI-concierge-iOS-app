//
//  SocketManager.swift
//  masai
//
//  Created by Bartomiej Burzec on 25.01.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//

import UIKit
import Starscream
import SwiftyJSON

public typealias SocketManagerConnectionCompletion = (WebSocket? , Bool) -> Void
public typealias SocketManagerMessageCompletion = (SocketResponseMessage) -> Void

class SocketManager {
    
    static let sharedInstance = SocketManager()
    private init() {}
    
    var sockets = [String: WebSocket]()
    
    var responseQueue = [String: [String : SocketManagerMessageCompletion]]()
    //TODO: delegates for concrete connection
    var connectionDelegates = [String: SocketManagerConnectionDelegate]()
    //FIXME: conversation delegates not handle rid per host
    var subscribedConversationDelegates = [String: [SubscribedConversationDelegate]]()
    var shouldReconnect = true
    var reconectigAttemps = 0
    
    internal var connectionCompletions = [String: SocketManagerConnectionCompletion]()
    
    func clear() {
        self.subscribedConversationDelegates = [String: [SubscribedConversationDelegate]]()
    }
    
    func isConnected(with conversation: Conversation) -> Bool {
        if let urlString = conversation.host?.socket {
            let socket = self.socket(with: URL(string: urlString)!)
            return socket.isConnected
        }
        
        return false
    }
    
    private func socket(with url:URL) -> WebSocket {
        if let socket = self.sockets[url.absoluteString] {
            return socket
        }
        
        let newSocket = WebSocket(url: url)
        newSocket.delegate = self
        newSocket.pongDelegate = self
        
        self.sockets[url.absoluteString] = newSocket
        return newSocket
    }
    
    static func connect(url: URL, completion: @escaping SocketManagerConnectionCompletion) {
        sharedInstance.connectionCompletions[url.absoluteString] = completion
        let socket = sharedInstance.socket(with: url)
        
        if socket.isConnected {
            completion(socket, socket.isConnected)
            return
        }
        
        socket.connect()
    }
    
    static func connect(_ host: Host, completion: @escaping SocketManagerConnectionCompletion) {
        if let socketAddress = host.socket {
            connect(url:URL(string: socketAddress)!, completion: completion)
        } else {
            completion(nil, false)
        }
    }
    
    static func disconnect(_ url: URL, completion: @escaping SocketManagerConnectionCompletion) {
        let key = url.absoluteString
        if let socket = sharedInstance.sockets[key] {
            sharedInstance.connectionCompletions[key] = completion
            socket.disconnect()
        } else {
            completion(nil, false)
        }
    }
    
    static func disconnect(_ host: Host, complection: @escaping SocketManagerConnectionCompletion) {
        if let socketAddress = host.socket {
            disconnect(URL(string: socketAddress)!, completion: complection)
        } else {
            complection(nil, false)
        }
    }
    
    static func send(_ object: [String: Any], url: URL,completionResponse: SocketManagerMessageCompletion? = nil) {
        let socket = sharedInstance.socket(with: url)
        if socket.isConnected {
            var jsonObject = JSON(object)
            let uniqueMessageIdentifier  = String.random(length: 50)
            
            jsonObject["id"] = JSON(uniqueMessageIdentifier)
            
            if let jsonString = jsonObject.rawString() {
                socket.write(string: jsonString, completion: nil)
            } else {
                print("[SocketManager]: Send - Invalid JSON")
            }
            
            if let completion = completionResponse {
                if sharedInstance.responseQueue[url.absoluteString] != nil {
                    sharedInstance.responseQueue[url.absoluteString]![uniqueMessageIdentifier] = completion
                } else {
                    sharedInstance.responseQueue[url.absoluteString] = [uniqueMessageIdentifier: completion]
                }
            }
        }
    }
    
    static func send(_ object: [String: Any], host: Host,completionResponse: SocketManagerMessageCompletion? = nil) {
        if let socketAddress = host.socket {
            self.send(object, url: URL(string:socketAddress)!, completionResponse: completionResponse)
        } else {
            //TODO: Make special error for this case
        }
    }
    
    static func renewSubscription(url: URL, rid: String) {
        
        let requestObject = [
            Constants.Network.Json.message : Constants.Network.Json.subscribe,
            Constants.Network.Json.name : Constants.Network.Json.roomStream,
            Constants.Network.Json.params: [rid, false]
            ] as [String : Any]
        
        send(requestObject, url: url)
    }
    
    
    static func subscribe(conversation: Conversation, delegate: SubscribedConversationDelegate) {
        if let rid = conversation.channel?.rid, let hostURL = conversation.host?.socket {
            if sharedInstance.subscribedConversationDelegates[rid] != nil {
                sharedInstance.subscribedConversationDelegates[rid]!.append(delegate)
            } else {
                sharedInstance.subscribedConversationDelegates[rid] = [delegate]
                
                let url = URL(string: hostURL)!
                renewSubscription(url: url, rid: rid)
            }
        }
    }
    
    static func unsubscribe(conversation: Conversation, delegate: SubscribedConversationDelegate) {
        if let rid = conversation.channel?.rid, sharedInstance.subscribedConversationDelegates[rid] != nil {
            for (index, delegateToRemove) in (sharedInstance.subscribedConversationDelegates[rid]?.enumerated().reversed())! {
                if delegateToRemove.delegateIdentifier() == delegate.delegateIdentifier() {
                    sharedInstance.subscribedConversationDelegates[rid]?.remove(at: index)
                }
            }
        }
    }
    
    static func connectionObject() -> [String: Any] {
        return ["msg" : "connect", "version" : "1", "support" : ["1", "pre2", "pre1"]] as [String: Any]
    }
    
    static func addConnectionDelegate(_ delegate: SocketManagerConnectionDelegate) -> Bool {
        if sharedInstance.connectionDelegates[delegate.delegateIdentifier()] != nil {
            return false
        }
        
        sharedInstance.connectionDelegates[delegate.delegateIdentifier()] = delegate
        return true
    }
    
    static func removeConnectionDelegate(_ delegate: SocketManagerConnectionDelegate) {
        if (sharedInstance.connectionDelegates[delegate.delegateIdentifier()] != nil) {
            sharedInstance.connectionDelegates.removeValue(forKey: delegate.delegateIdentifier())
        }
    }
    
    static func getConversationsWith(url: String) -> [Conversation] {
        var conversationsWithUrl = [Conversation]()
    
        if let conversations = CacheManager.retrieveConversationList() {
            for conversation in conversations {
                if conversation.host?.socket == url {
                    conversationsWithUrl.append(conversation)
                }
            }
        }
        
        return conversationsWithUrl
    }
}


extension SocketManager: WebSocketDelegate {
    func websocketDidConnect(socket: WebSocket) {
        print("Socket connected with host: \(socket.key())")
        
        SocketManager.send(SocketManager.connectionObject(), url: socket.currentURL)
        
        if let completionForSocket = self.connectionCompletions[socket.currentURL.absoluteString] {
            completionForSocket(socket, socket.isConnected)
        }
        
        for (_, delegate) in self.connectionDelegates {
            delegate.onSocketConnected()
        }
        
        if socket.reconnecting {
            socket.reconnecting = false
            let conversationsForUrl = SocketManager.getConversationsWith(url: socket.key())
            for conversation in conversationsForUrl {
                if let host = conversation.host, let token = conversation.credentials?.liveChatToken {
                    
                    SocketRequestManager.loginToLiveChat(host: host, token: token, completion: { (response) in
                    
                        SocketRequestManager.loadHistory(conversation)
                        for rid in self.subscribedConversationDelegates {
                            SocketManager.renewSubscription(url: URL(string: socket.key())!, rid: rid.key)
                        }
                        
                        self.resentUnsentMessages(conversation)
                        
                        let appDelegate = UIApplication.shared.delegate as! AppDelegate
                        appDelegate.onReconnectToHost()
                    })
                }
            }
        }
        
    }
    
    func resentUnsentMessages(_ conversation: Conversation) {
        let unsentMessages = conversation.unsentMessages()
        for msg in unsentMessages {
            switch msg.dataType() {
            case .image:
                UploadManager.sharedInstance.reupload(conversation: conversation, message: msg)
            case .location:
                SocketRequestManager.resendLocalization(conversation, message: msg)
            default:
                SocketRequestManager.resendTextMessage(conversation, message: msg)
            }
        }
    }
    
    func websocketDidDisconnect(socket: WebSocket, error: NSError?) {
        print("[WebSocket]: connection did disconnect with error (\(error))")
        
        let key = socket.key()
        if let connectionCompletion = self.connectionCompletions[key] {
            //            connectionCompletion(socket, socket.isConnected)
            //FIXME: not good solution
            connectionCompletions.removeValue(forKey: key)
        }
        
        if self.responseQueue[key] != nil {
            self.responseQueue.removeValue(forKey: key)
        }
       
        if self.shouldReconnect {
            socket.reconnecting = true
            socket.connect()
        }
        
    }
    
    func websocketDidReceiveData(socket: WebSocket, data: Data) {
        print("[WebSocket] did receive data (\(data))")
    }
    
    func websocketDidReceiveMessage(socket: WebSocket, text: String) {
        let jsonMessage = JSON.init(parseJSON: text)
        
        if let jsonString =  jsonMessage.rawString() {
            print("[WebSocket] Recieved message - \(jsonString)")
            handleResponse(jsonMessage, socket: socket)
        } else {
            print("[WebSocket] Recived Message - Invalid Json \(text)")
        }
    }
}

extension SocketManager: WebSocketPongDelegate {
    func websocketDidReceivePong(socket: WebSocket, data: Data?) {
        print("[WebSocketManager] PONG")
    }
    
}
