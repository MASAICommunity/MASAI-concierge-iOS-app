//
//  CacheManager.swift
//  masai
//
//  Created by Bartłomiej Burzec on 07.02.2017.
//  Copyright © 2017 Embiq sp. z o.o. All rights reserved.
//
import Pantry
import Foundation

struct CacheManager {
    
    private static let photoDirectory = "/masai_cache_photo"
    
    static func saveConversationList(_ list: [Conversation]) {
        Pantry.pack(list, key: Constants.Cache.conversationList)
    }
    
    static func retrieveConversationList() -> [Conversation]? {
        return Pantry.unpack(Constants.Cache.conversationList)
    }
    
    static func removeConversationList() {
        Pantry.expire(Constants.Cache.conversationList)
    }
    
    static func saveLoggedUser(_ user: User) {
        Pantry.pack(user, key: Constants.Cache.user)
    }
    
    static func retrieveLoggedUser() -> User? {
        return Pantry.unpack(Constants.Cache.user)
    }
    
    static func removeLoggedUser() {
        Pantry.expire(Constants.Cache.user)
    }
    
    private static func imagesDirectoryPath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectorPath:String = paths[0]
        
        return "\(documentDirectorPath)\(photoDirectory)"
    }
    
    private static func path(_ filename: String) -> String {
        return "\(imagesDirectoryPath())\(filename).jpg"
    }
    
    
    static func cacheImage(_ data: Data, filename: String) {
        var objcBool =  ObjCBool(true)
        if FileManager.default.fileExists(atPath: imagesDirectoryPath(), isDirectory: &objcBool) == false {
            do {
                try FileManager.default.createDirectory(atPath: imagesDirectoryPath(), withIntermediateDirectories: true, attributes: nil)
                //TODO: exlude from iCloud backup
            }  catch _ {
                print("Niepowodzenie tworzenia folderu dla zdjęć")
            }
        }
        
        let imagePath = path(filename)
        
        FileManager.default.createFile(atPath: imagePath, contents: data, attributes: nil)
    }
    
    static func cacheImage(_ image: UIImage, filename: String) {
        if let imageData = UIImageJPEGRepresentation(image, 0.8) {
            cacheImage(imageData, filename: filename)
        }
    }
    
    static func cachedImage(_ filename: String) -> UIImage? {
        if let data = FileManager.default.contents(atPath: path(filename)) {
            return UIImage(data: data)
        }
        return nil
    }
    
    static func removeCachedImage(_ filename: String) {
        do {
           try FileManager.default.removeItem(atPath: path(filename))
        } catch _ {
            print("Niepowodzenia usuwania zdjęcia")
        }
    }
    
}
